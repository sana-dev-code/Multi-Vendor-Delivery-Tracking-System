from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.models.vendor import Vendor
from app.models.driver import Driver
from app.schemas.vendor import VendorCreate
from app.schemas.driver import DriverCreate

from app.core.dependencies import get_current_admin


router = APIRouter(
    prefix="/admin",
    tags=["Admin"]
)


@router.post("/vendors")
def create_vendor(
    request: VendorCreate,
    db: Session = Depends(get_db),
    admin=Depends(get_current_admin)
):
    vendor = Vendor(**request.model_dump())

    db.add(vendor)
    db.commit()
    db.refresh(vendor)

    return vendor


@router.post("/drivers")
def create_driver(
    request: DriverCreate,
    db: Session = Depends(get_db),
    admin=Depends(get_current_admin)
):
    driver = Driver(**request.model_dump())

    db.add(driver)
    db.commit()
    db.refresh(driver)

    return driver